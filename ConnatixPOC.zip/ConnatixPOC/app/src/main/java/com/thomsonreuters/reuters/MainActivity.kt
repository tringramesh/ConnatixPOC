package com.thomsonreuters.reuters

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.LinearLayout
import com.cnx.connatixplayersdk.*

class MainActivity : AppCompatActivity(), Listenable {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val sdkContainerView = findViewById<LinearLayout>(R.id.sdkContainerView)
        val playspacePlayer = PlayspacePlayer(this, null, 0, this)
        val params : LinearLayout.LayoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT)
        playspacePlayer.layoutParams = params
        sdkContainerView.addView(playspacePlayer)
        val playerSettings = PlayerSettings(useExternalViewabilityService = true,playbackMode = 0,defaultSoundMode =0,nextVideoMode = 0)
        val appSettings = AppSettings("https://www.reuters.com","https://play.google.com/store/apps/details?id=com.thomsonreuters.reuters", listOf("news", "magazine"),true,false)
        val playerConfig = PlayspaceConfig("3d097366-2276-4c4b-b564-3cbd9b6c30cd", "5bd62672-d010-47f0-bab2-145b331085c6", appSettings,playerSettings)
        playspacePlayer.setupPlayer( playerConfig)
        playspacePlayer.listenFor(EventType.changeSlide,true)
    }

    override fun receivedConnatixEvent(event: Event) {
       Log.i("Event",event.toString())
    }
}