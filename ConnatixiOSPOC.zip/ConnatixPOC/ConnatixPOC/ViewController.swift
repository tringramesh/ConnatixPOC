//
//  ViewController.swift
//  ConnatixPOC
//
//  Created by Tringapps on 23/10/20.
//

import UIKit
import ConnatixPlayerSDK

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let category = ["news", "Financial News"]
        let appSettings =  AppSettings("com.thomsonreuters.Reuters", "reuters.com","https://apps.apple.com/us/app/reuters-news/id602660809",category,true,false)

        let elementsConfig = ElementsConfig("63f8f823-5fc3-4f97-993d-6fb6b8eee67d", appSettings)
        //New player instance
        let elementsPlayer = ElementsPlayer(self.view.bounds)
        elementsPlayer.setConfig(elementsConfig)
        
        //Listen for events
        elementsPlayer.listenFor(EventType.play, false)
        elementsPlayer.backgroundColor = .red
      
        //Insert player as a subview
        self.view.insertSubview(elementsPlayer, at: 0)
    }
}

